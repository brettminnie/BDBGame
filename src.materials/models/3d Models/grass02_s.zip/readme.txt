copyright 2000 3dplants.com

Model created by Drew Costigan

This model is free for commercial or non-commercial use. Sale or unauthorized commercial distribution of this model in any form is prohibited. Please distribute the file only in it's original unmodified zipped format with copyright text intact.

CUSTOM 3D MODEL DESIGN SERVICES AVAILABLE, CONTACT:
grafix@snakebite.com or creativegrafix@aol.com

OR VISIT:
http://www7.50megs.com/grafix/custom.html

Illustration, Animation & Graphic Design:
http://members.aol.com/creativegrafix



*******

www.3dplants.com


